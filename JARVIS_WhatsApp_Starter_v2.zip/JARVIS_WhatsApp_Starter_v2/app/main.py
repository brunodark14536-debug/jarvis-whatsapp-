import hashlib
import hmac
import json
import logging
import os
import sqlite3
from contextlib import contextmanager
from typing import Any

import httpx
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import PlainTextResponse
from openai import AsyncOpenAI

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
log = logging.getLogger("jarvis")

app = FastAPI(title="J.A.R.V.I.S. WhatsApp Assistant")

VERIFY_TOKEN = os.getenv("WHATSAPP_VERIFY_TOKEN", "")
META_APP_SECRET = os.getenv("META_APP_SECRET", "")
META_TOKEN = os.getenv("WHATSAPP_ACCESS_TOKEN", "")
PHONE_NUMBER_ID = os.getenv("WHATSAPP_PHONE_NUMBER_ID", "")
GRAPH_VERSION = os.getenv("META_GRAPH_VERSION", "")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")
DATABASE_PATH = os.getenv("DATABASE_PATH", "jarvis.sqlite3")

SYSTEM_INSTRUCTIONS = (
    "Você é J.A.R.V.I.S., um assistente virtual em português brasileiro. "
    "Seja educado, claro, conciso, profissional e discreto. "
    "Você pode ajudar a organizar tarefas e explicar como criar lembretes, "
    "mas não alegue ter executado ações externas sem uma integração real. "
    "Peça confirmação antes de ações importantes ou irreversíveis. "
    "Nunca solicite senhas, códigos de autenticação ou chaves secretas."
)

def open_db():
    conn = sqlite3.connect(DATABASE_PATH, timeout=15)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            wa_message_id TEXT UNIQUE,
            phone TEXT NOT NULL,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_messages_phone_id ON messages(phone, id)")
    conn.commit()
    return conn

@contextmanager
def db_connection():
    conn = open_db()
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()

def already_processed(wa_message_id: str) -> bool:
    with db_connection() as conn:
        row = conn.execute(
            "SELECT 1 FROM messages WHERE wa_message_id = ? LIMIT 1",
            (wa_message_id,)
        ).fetchone()
        return row is not None

def save_message(phone: str, role: str, content: str, wa_message_id: str | None = None):
    with db_connection() as conn:
        conn.execute(
            "INSERT OR IGNORE INTO messages (wa_message_id, phone, role, content) VALUES (?, ?, ?, ?)",
            (wa_message_id, phone, role, content)
        )

def get_history(phone: str, limit: int = 12) -> list[dict[str, str]]:
    with db_connection() as conn:
        rows = conn.execute(
            "SELECT role, content FROM messages WHERE phone = ? ORDER BY id DESC LIMIT ?",
            (phone, limit)
        ).fetchall()
    rows.reverse()
    return [{"role": role, "content": content} for role, content in rows]

def verify_meta_signature(raw_body: bytes, signature_header: str | None) -> bool:
    if not META_APP_SECRET or not signature_header:
        return False
    expected = "sha256=" + hmac.new(
        META_APP_SECRET.encode("utf-8"), raw_body, hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(expected, signature_header)

async def generate_reply(phone: str, user_text: str) -> str:
    if not OPENAI_API_KEY:
        raise RuntimeError("OPENAI_API_KEY não configurada.")
    client = AsyncOpenAI(api_key=OPENAI_API_KEY)
    history = get_history(phone)
    # The incoming user message is saved after generation to avoid duplicate context.
    response_input = history + [{"role": "user", "content": user_text}]
    response = await client.responses.create(
        model=OPENAI_MODEL,
        instructions=SYSTEM_INSTRUCTIONS,
        input=response_input,
    )
    return (response.output_text or "").strip() or "Não consegui formular uma resposta agora."

async def send_whatsapp_text(to_number: str, message: str) -> None:
    if not (META_TOKEN and PHONE_NUMBER_ID and GRAPH_VERSION):
        raise RuntimeError("Configuração da WhatsApp Cloud API incompleta.")
    url = f"https://graph.facebook.com/{GRAPH_VERSION}/{PHONE_NUMBER_ID}/messages"
    headers = {"Authorization": f"Bearer {META_TOKEN}"}
    payload = {
        "messaging_product": "whatsapp",
        "recipient_type": "individual",
        "to": to_number,
        "type": "text",
        "text": {"preview_url": False, "body": message[:4096]},
    }
    async with httpx.AsyncClient(timeout=20) as client:
        result = await client.post(url, headers=headers, json=payload)
        result.raise_for_status()

@app.get("/health")
async def health():
    return {"status": "ok", "service": "jarvis-whatsapp"}

@app.get("/webhook")
async def verify_webhook(request: Request):
    params = request.query_params
    mode = params.get("hub.mode")
    token = params.get("hub.verify_token")
    challenge = params.get("hub.challenge")
    if mode == "subscribe" and VERIFY_TOKEN and hmac.compare_digest(token or "", VERIFY_TOKEN) and challenge:
        return PlainTextResponse(challenge)
    raise HTTPException(status_code=403, detail="Verificação do webhook recusada.")

@app.post("/webhook")
async def receive_webhook(request: Request):
    raw_body = await request.body()
    signature = request.headers.get("X-Hub-Signature-256")
    if not verify_meta_signature(raw_body, signature):
        raise HTTPException(status_code=401, detail="Assinatura do webhook inválida.")

    try:
        data: dict[str, Any] = json.loads(raw_body)
    except json.JSONDecodeError as exc:
        raise HTTPException(status_code=400, detail="JSON inválido.") from exc

    try:
        for entry in data.get("entry", []):
            for change in entry.get("changes", []):
                value = change.get("value", {})
                for message in value.get("messages", []):
                    sender = message.get("from")
                    message_id = message.get("id")
                    if not sender or not message_id or message.get("type") != "text":
                        continue
                    if already_processed(message_id):
                        continue

                    user_text = (message.get("text", {}).get("body") or "").strip()
                    if not user_text:
                        continue

                    # Save the inbound ID first to make webhook retries idempotent.
                    save_message(sender, "user", user_text, message_id)
                    try:
                        reply = await generate_reply(sender, user_text)
                        save_message(sender, "assistant", reply)
                        await send_whatsapp_text(sender, reply)
                    except Exception:
                        log.exception("Falha ao processar mensagem recebida.")
                        # Do not expose internal errors or credentials to the sender.
        return {"received": True}
    except Exception as exc:
        log.exception("Falha ao processar evento do webhook.")
        raise HTTPException(status_code=500, detail="Falha interna ao processar evento.") from exc
