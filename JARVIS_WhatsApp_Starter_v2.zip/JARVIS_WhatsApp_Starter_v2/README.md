# J.A.R.V.I.S. — base segura para WhatsApp Cloud API

Este pacote é uma base de desenvolvimento. Não está conectado a contas Meta/OpenAI e não fica ativo até ser hospedado e configurado.

## Incluído
- FastAPI com `GET /health`.
- Verificação do webhook da Meta em `GET /webhook`.
- Validação HMAC SHA-256 do cabeçalho `X-Hub-Signature-256` em `POST /webhook`.
- Processamento de mensagens de texto recebidas.
- Histórico curto por contato em SQLite.
- Proteção básica contra reprocessamento de IDs de mensagem.
- Respostas pela OpenAI Responses API e envio via WhatsApp Cloud API.

## Teste local
Requer Python 3.11 ou superior.

```bash
python -m venv .venv
# Linux/macOS:
source .venv/bin/activate
# Windows:
# .venv\\Scripts\\activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

O endpoint `/health` deve responder com `status: ok`.

## Configuração para hospedagem
Configure as variáveis de `.env.example` no gerenciador de secrets do provedor. Não envie valores secretos por chat e não comite `.env`.

A hospedagem precisa:
- oferecer HTTPS público;
- executar `uvicorn app.main:app --host 0.0.0.0 --port $PORT` (adapte `$PORT` ao provedor);
- preservar armazenamento persistente para `jarvis.sqlite3`, ou trocar SQLite por banco gerenciado;
- manter os secrets fora do código.

No painel Meta, configure o callback como `https://SEU-DOMINIO/webhook`, o token de verificação correspondente e a assinatura do evento `messages`. Use credenciais e número que o titular autorizado controla.

## Importante antes de produção
- Este starter processa apenas mensagens de texto. Áudios, imagens, documentos e templates ainda não estão implementados.
- Para produção com maior volume, use fila de tarefas e banco de dados gerenciado em vez de processar tudo dentro do webhook.
- Configure limites de uso, alertas de custos, política de privacidade e retenção de dados.
- Teste a assinatura do webhook com eventos reais do ambiente Meta.
- A memória atual mantém apenas histórico de mensagens; não é uma memória semântica ou perfil persistente.
- Não execute ações externas sensíveis sem confirmação explícita.
